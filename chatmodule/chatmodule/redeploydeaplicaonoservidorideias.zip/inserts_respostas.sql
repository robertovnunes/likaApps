USE `paciente_virtual` ;

INSERT INTO resposta (id_caso_clinico, id_secao, id_topico, id_resposta, texto) VALUES ( 1, 1, 1, 1, 'Meu nome é Alfredo José Marques' ) ;
INSERT INTO resposta (id_caso_clinico, id_secao, id_topico, id_resposta, texto) VALUES ( 1, 1, 2, 1, 'Tenho 45 anos' ) ;
INSERT INTO resposta (id_caso_clinico, id_secao, id_topico, id_resposta, texto) VALUES ( 1, 1, 3, 1, 'dezenove de dezembro de mil novecentos de sessenta e sete (19/12/1967)' ) ;
INSERT INTO resposta (id_caso_clinico, id_secao, id_topico, id_resposta, texto) VALUES ( 1, 1, 4, 1, 'Pardo' ) ;
INSERT INTO resposta (id_caso_clinico, id_secao, id_topico, id_resposta, texto) VALUES ( 1, 1, 5, 1, 'Masculino' ) ;
INSERT INTO resposta (id_caso_clinico, id_secao, id_topico, id_resposta, texto) VALUES ( 1, 1, 6, 1, 'Vim de minha casa' ) ;
INSERT INTO resposta (id_caso_clinico, id_secao, id_topico, id_resposta, texto) VALUES ( 1, 1, 7, 1, 'Sim' ) ;
INSERT INTO resposta (id_caso_clinico, id_secao, id_topico, id_resposta, texto) VALUES ( 1, 1, 8, 1, 'Recife' ) ;
INSERT INTO resposta (id_caso_clinico, id_secao, id_topico, id_resposta, texto) VALUES ( 1, 1, 9, 1, 'Sim' ) ;
INSERT INTO resposta (id_caso_clinico, id_secao, id_topico, id_resposta, texto) VALUES ( 1, 1, 10, 1, 'CDU' ) ;
INSERT INTO resposta (id_caso_clinico, id_secao, id_topico, id_resposta, texto) VALUES ( 1, 1, 11, 1, 'Sou casado há 25 anos' ) ;
INSERT INTO resposta (id_caso_clinico, id_secao, id_topico, id_resposta, texto) VALUES ( 1, 1, 12, 1, 'três filhos' ) ;
INSERT INTO resposta (id_caso_clinico, id_secao, id_topico, id_resposta, texto) VALUES ( 1, 1, 13, 1, '19, 20 e 22 anos' ) ;
INSERT INTO resposta (id_caso_clinico, id_secao, id_topico, id_resposta, texto) VALUES ( 1, 1, 14, 1, 'Até o 2º grau completo' ) ;
INSERT INTO resposta (id_caso_clinico, id_secao, id_topico, id_resposta, texto) VALUES ( 1, 1, 15, 1, 'Sou motorista de ônibus' ) ;
INSERT INTO resposta (id_caso_clinico, id_secao, id_topico, id_resposta, texto) VALUES ( 1, 1, 16, 1, 'Tontura, dor no peito e ando cansado e desmaiei ontem, às vezes sinto meu coração acelerado' ) ;

INSERT INTO resposta (id_caso_clinico, id_secao, id_topico, id_resposta, texto) VALUES ( 1, 2, 1, 1, 'Nenhuma grave além de um infarto a 10 meses' ) ;
INSERT INTO resposta (id_caso_clinico, id_secao, id_topico, id_resposta, texto) VALUES ( 1, 2, 2, 1, 'Já, por causa do infarto' ) ;
INSERT INTO resposta (id_caso_clinico, id_secao, id_topico, id_resposta, texto) VALUES ( 1, 2, 3, 1, 'Sim, por causa do infarto' ) ;

INSERT INTO resposta (id_caso_clinico, id_secao, id_topico, id_resposta, texto) VALUES ( 1, 3, 1, 1, 'Meu pai teve hipertensão e diabetes, faleceu de infarto aos 87 anos e minhas duas irmãs têm hipertensão' ) ;

INSERT INTO resposta (id_caso_clinico, id_secao, id_topico, id_resposta, texto) VALUES ( 1, 4, 1, 1, 'Comigo moram quatro pessoas' ) ;
INSERT INTO resposta (id_caso_clinico, id_secao, id_topico, id_resposta, texto) VALUES ( 1, 4, 2, 1, 'É de alvenaria' ) ;
INSERT INTO resposta (id_caso_clinico, id_secao, id_topico, id_resposta, texto) VALUES ( 1, 4, 3, 1, 'Na minha casa tem coleta de lixo, esgoto e água encanada' ) ;

INSERT INTO resposta (id_caso_clinico, id_secao, id_topico, id_resposta, texto) VALUES ( 1, 5, 1, 1, 'Tenho um bom relacionamento com minha família, esposa, filhos e meus pais' ) ;
INSERT INTO resposta (id_caso_clinico, id_secao, id_topico, id_resposta, texto) VALUES ( 1, 5, 2, 1, 'Sou católico' ) ;
INSERT INTO resposta (id_caso_clinico, id_secao, id_topico, id_resposta, texto) VALUES ( 1, 5, 3, 1, 'Ahh, eu tomo uma cervejinha com churrasco mais uns amigos nos finais de semana' ) ;
INSERT INTO resposta (id_caso_clinico, id_secao, id_topico, id_resposta, texto) VALUES ( 1, 5, 4, 1, 'Eu tenho normal, doutora' ) ;
INSERT INTO resposta (id_caso_clinico, id_secao, id_topico, id_resposta, texto) VALUES ( 1, 5, 5, 1, 'Não doutora, eu não tenho' ) ;
INSERT INTO resposta (id_caso_clinico, id_secao, id_topico, id_resposta, texto) VALUES ( 1, 5, 6, 1, 'Eu bebo socialmente e não fumo a 5 anos, mas fumei por 20 anos' ) ;
INSERT INTO resposta (id_caso_clinico, id_secao, id_topico, id_resposta, texto) VALUES ( 1, 5, 7, 1, 'Não, nunca usei' ) ;
INSERT INTO resposta (id_caso_clinico, id_secao, id_topico, id_resposta, texto) VALUES ( 1, 5, 8, 1, 'Sim, tomo aprazolam e propranolol por causa do meu problema' ) ;
INSERT INTO resposta (id_caso_clinico, id_secao, id_topico, id_resposta, texto) VALUES ( 1, 5, 9, 1, 'Não, acordo cansado' ) ;
INSERT INTO resposta (id_caso_clinico, id_secao, id_topico, id_resposta, texto) VALUES ( 1, 5, 10, 1, 'Tenho dificuldade para dormir por que fico preocupado e ansioso com o meu problema' ) ;
INSERT INTO resposta (id_caso_clinico, id_secao, id_topico, id_resposta, texto) VALUES ( 1, 5, 11, 1, 'Não' ) ;
INSERT INTO resposta (id_caso_clinico, id_secao, id_topico, id_resposta, texto) VALUES ( 1, 5, 12, 1, 'Dependendo do dia que trabalho faço caminhadas no fim da tarde' ) ;
INSERT INTO resposta (id_caso_clinico, id_secao, id_topico, id_resposta, texto) VALUES ( 1, 5, 13, 1, 'Sim, mais por conta do trabalho' ) ;
INSERT INTO resposta (id_caso_clinico, id_secao, id_topico, id_resposta, texto) VALUES ( 1, 5, 14, 1, 'Comia de tudo e na hora certa, café da manhã, almoço e janta' ) ;
INSERT INTO resposta (id_caso_clinico, id_secao, id_topico, id_resposta, texto) VALUES ( 1, 5, 15, 1, 'Acho que vou ao banheiro uma vez a cada dois dias' ) ;
INSERT INTO resposta (id_caso_clinico, id_secao, id_topico, id_resposta, texto) VALUES ( 1, 5, 16, 1, 'Eu ia fazer xixi duas ou três vezes ao dia' ) ;
INSERT INTO resposta (id_caso_clinico, id_secao, id_topico, id_resposta, texto) VALUES ( 1, 5, 17, 1, 'Dois banhos por dia' ) ;
INSERT INTO resposta (id_caso_clinico, id_secao, id_topico, id_resposta, texto) VALUES ( 1, 5, 18, 1, 'Sim, escovo os dentes direito e vou ao dentista sempre que preciso' ) ;
