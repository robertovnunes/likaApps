<?php
/**
 * ------------------------------------------------------------------------
 * JA Extenstion Manager Component for J25 & J32
 * ------------------------------------------------------------------------
 * Copyright (C) 2004-2011 J.O.O.M Solutions Co., Ltd. All Rights Reserved.
 * @license - GNU/GPL, http://www.gnu.org/licenses/gpl.html
 * Author: J.O.O.M Solutions Co., Ltd
 * Websites: http://www.joomlart.com - http://www.joomlancers.com
 * ------------------------------------------------------------------------
 */

//no direct access
defined( '_JEXEC' ) or die( 'Retricted Access' );
?>
<div align="diff-source">
<div id="diff-view-mode" style="display:none;">
<pre><code></code></pre>
</div>
<div id="diff-edit-mode" style="display:none; text-align:center;">
<form name="frmSource" id="frmSource" action="" enctype="multipart/form-data">
<textarea name="txtSource" id="txtSource" class="ja-editor-code" onscroll="scrollEditor(this);" wrap="off"></textarea>
</form>
<br />
</div>
</div>
