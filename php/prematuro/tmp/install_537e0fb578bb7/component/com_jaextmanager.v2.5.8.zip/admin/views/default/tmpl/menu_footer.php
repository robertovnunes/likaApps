<?php
/**
 * ------------------------------------------------------------------------
 * JA Extenstion Manager Component for J25 & J32
 * ------------------------------------------------------------------------
 * Copyright (C) 2004-2011 J.O.O.M Solutions Co., Ltd. All Rights Reserved.
 * @license - GNU/GPL, http://www.gnu.org/licenses/gpl.html
 * Author: J.O.O.M Solutions Co., Ltd
 * Websites: http://www.joomlart.com - http://www.joomlancers.com
 * ------------------------------------------------------------------------
 */

//no direct access
defined( '_JEXEC' ) or die( 'Retricted Access' );

?>
</div>
<div id="jacom-footer">
	<div id="logo">
    	<div style="width:230px; margin:0 auto;">
    	<a title="Powered by JoomlArt.com" href="http://www.joomlart.com" id="logo-jaextmanager" target="_blank">&nbsp;</a>
        </div>
    </div>	
    </div>
	</div>
<div class="clr"/>
</div>