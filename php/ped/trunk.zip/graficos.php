<?php
	include_once("controllers/ControllerGeral.php");
	include_once("controllers/ControllerGraficos.php");
	include_once("views/graficos_view.php");
?>