<?php
include_once("controllers/ControllerGeral.php");
include_once("classes/basicas/Paciente.php");
include_once("controllers/ControllerAlterarPaciente.php");
include_once("views/aluno_view.php");
include_once("views/alterar_paciente_view.php");
include_once("views/rodapeped.inc.php");
?>