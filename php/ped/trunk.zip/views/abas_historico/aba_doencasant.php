<br />
<span class="style7">Pessoal > Doen&ccedil;as Anteriores</span>
<br />

	<?php/*
	$vetor = array();
			
			if($coquel1)
				$vetor[] = 'Coqueluche';
			if($sarampo1)
				$vetor[] = 'Sarampo';
			if($varic1)
				$vetor[] = 'Varicela';
			if($parot1)
				$vetor[] = 'Parotide';
			if($dift1)
				$vetor[] = 'Difteria';
			if($tetano1)
				$vetor[] = 'T�tano';
			if($diarr1)
				$vetor[] = 'Diarr�ia';
			if($pneum1)
				$vetor[] = 'Pneumonia';
			if($mening1)
				$vetor[] = 'Menigite';
			if($febrer1)
				$vetor[] = 'Febre Reum�tica';
			if($nefro1)
				$vetor[] = 'Nefropatia';
			if($tuberc1)
				$vetor[] = 'Tuberculose';
			if($eczema1)
				$vetor[] = 'Eczema';
			if($asma1)
				$vetor[] = 'Asma';
			if($rinite1)
				$vetor[] = 'Rinite Al�rgica';
			if($cirurg1)
				$vetor[] = 'Cirurgias e Acidentes';
			if($transf1)
				$vetor[] = 'Tranfus�es';
			if($hospit1)
				$vetor[] = 'Hospitaliza��es';
			if($alerg1)
				$vetor[] = 'Alergia Alimentar';
			
			
	if($coquel1 || $sarampo1 || $varic1 || $parot1 || $dift1 || $tetano1 || $diarr1 || $pneum1 || $mening1 || $febrer1 || $nefro1 || $tuberc1 || $eczema1 || $asma1 || $alerg1 || $rinite1 || $cirurg1 || $transf1 || $hospit1){?>		
	
	<fieldset style="width:94%">
	<legend>Tabela de Doen�as</legend>
	<span>
	<table>
		
		<tr>
		
		<? 
		for($i=0;$i<5;$i++){
		?>
			
			<td width="25%">
				<font size='2' color="666666"><? echo "$vetor[$i]"; ?></font> 
			</td>
			
		<?} 		
		?>
		
		</tr>
		<tr>
		
		<?
		for($i = 5; $i<10; $i++){
		?>	
			<td width="25%">
				<font size='2' color="666666"><? echo "$vetor[$i]"; ?></font> 
			</td>
			
		<?}			
		?>
		</tr>
		<tr>
		
		<?
		for($i = 10; $i<15; $i++){
		?>	
			<td width="25%">
				<font size='2' color="666666"><? echo "$vetor[$i]"; ?></font> 
			</td>
			
		<?}			
		?>
		</tr>
		<tr>
		
		<?
		for($i = 15; $i<20; $i++){
		?>	
			<td width="25%">
				<font size='2' color="666666"><? echo "$vetor[$i]"; ?></font> 
			</td>
			
		<?}			
		?>
		</tr>
	
	</table>
	</span>
	</fieldset>
			
		<?}
	
	*/?>

<fieldset style="width:46%">
	<legend>Coqueluche</legend>
	<span>
		<input name="coquel" type="radio" value="S" onchange="savCampo('8')" <?php echo $coquel1; ?>/><label>Sim</label>
		<input name="coquel" type="radio" value="N" onchange="savCampo('8')" <?php echo $coquel2; ?>/><label>N&atilde;o</label>
		<input name="coquel" type="radio" value="NA" onchange="savCampo('8')" <?php echo $coquel3; ?>/><label>N&atilde;o Avaliado</label>
	</span>
</fieldset>
<fieldset style="width:46%">
	<legend>Sarampo</legend>
	<span>
		<input name="sarampo" type="radio" value="S" onchange="savCampo('8')" <?php echo $sarampo1; ?>/><label>Sim</label>
		<input name="sarampo" type="radio" value="N" onchange="savCampo('8')" <?php echo $sarampo2; ?>/><label>N&atilde;o</label>
		<input name="sarampo" type="radio" value="NA" onchange="savCampo('8')" <?php echo $sarampo3; ?>/><label>N&atilde;o Avaliado</label>
	</span>
</fieldset>

<fieldset style="width:46%">
	<legend>Varicela</legend>
	<span>
		<input name="varic" type="radio" value="S" onchange="savCampo('8')" <?php echo $varic1; ?>/><label>Sim</label>
		<input name="varic" type="radio" value="N" onchange="savCampo('8')" <?php echo $varic2; ?>/><label>N&atilde;o</label>
		<input name="varic" type="radio" value="NA" onchange="savCampo('8')" <?php echo $varic3; ?>/><label>N&atilde;o Avaliado</label>
	</span>
</fieldset>
<fieldset style="width:46%">
	<legend>Parotide</legend>
	<span>
		<input name="parot" type="radio" value="S" onchange="savCampo('8')" <?php echo $parot1; ?>/><label>Sim</label>
		<input name="parot" type="radio" value="N" onchange="savCampo('8')" <?php echo $parot2; ?>/><label>N&atilde;o</label>
		<input name="parot" type="radio" value="NA" onchange="savCampo('8')" <?php echo $parot3; ?>/><label>N&atilde;o Avaliado</label>
	</span>
</fieldset>

<fieldset style="width:46%">
	<legend>Difteria</legend>
	<span>
		<input name="dift" type="radio" value="S" onchange="savCampo('8')" <?php echo $dift1; ?>/><label>Sim</label>
		<input name="dift" type="radio" value="N" onchange="savCampo('8')" <?php echo $dift2; ?>/><label>N&atilde;o</label>
		<input name="dift" type="radio" value="NA" onchange="savCampo('8')" <?php echo $dift3; ?>/><label>N&atilde;o Avaliado</label>
	</span>
</fieldset>
<fieldset style="width:46%">
	<legend>T&eacute;tano</legend>
	<span>
		<input name="tetano" type="radio" value="S" onchange="savCampo('8')" <?php echo $tetano1; ?>/><label>Sim</label>
		<input name="tetano" type="radio" value="N" onchange="savCampo('8')" <?php echo $tetano2; ?>/><label>N&atilde;o</label>
		<input name="tetano" type="radio" value="NA" onchange="savCampo('8')" <?php echo $tetano3; ?>/><label>N&atilde;o Avaliado</label>
	</span>
</fieldset>

<fieldset style="width:46%">
	<legend>Diarr&eacute;ia</legend>
	<span>
		<input name="diarr" type="radio" value="S" onchange="savCampo('8')" <?php echo $diarr1; ?>/><label>Sim</label>
		<input name="diarr" type="radio" value="N" onchange="savCampo('8')" <?php echo $diarr2; ?>/><label>N&atilde;o</label>
		<input name="diarr" type="radio" value="NA" onchange="savCampo('8')" <?php echo $diarr3; ?>/><label>N&atilde;o Avaliado</label>
	</span>
</fieldset>
<fieldset style="width:46%">
	<legend>Pneumonia</legend>
	<span>
		<input name="pneum" type="radio" value="S" onchange="savCampo('8')" <?php echo $pneum1; ?>/><label>Sim</label>
		<input name="pneum" type="radio" value="N" onchange="savCampo('8')" <?php echo $pneum2; ?>/><label>N&atilde;o</label>
		<input name="pneum" type="radio" value="NA" onchange="savCampo('8')" <?php echo $pneum3; ?>/><label>N&atilde;o Avaliado</label>
	</span>
</fieldset>

<fieldset style="width:46%">
	<legend>Meningite</legend>
	<span>
		<input name="mening" type="radio" value="S" onchange="savCampo('8')" <?php echo $mening1; ?>/><label>Sim</label>
		<input name="mening" type="radio" value="N" onchange="savCampo('8')" <?php echo $mening2; ?>/><label>N&atilde;o</label>
		<input name="mening" type="radio" value="NA" onchange="savCampo('8')" <?php echo $mening3; ?>/><label>N&atilde;o Avaliado</label>
	</span>
</fieldset>
<fieldset style="width:46%">
	<legend>Febre Reum&aacute;tica</legend>
	<span>
		<input name="febrer" type="radio" value="S" onchange="savCampo('8')" <?php echo $febrer1; ?>/><label>Sim</label>
		<input name="febrer" type="radio" value="N" onchange="savCampo('8')" <?php echo $febrer2; ?>/><label>N&atilde;o</label>
		<input name="febrer" type="radio" value="NA" onchange="savCampo('8')" <?php echo $febrer3; ?>/><label>N&atilde;o Avaliado</label>
	</span>
</fieldset>

<fieldset style="width:46%">
	<legend>Nefropatia</legend>
	<span>
		<input name="nefro" type="radio" value="S" onchange="savCampo('8')" <?php echo $nefro1; ?>/><label>Sim</label>
		<input name="nefro" type="radio" value="N" onchange="savCampo('8')" <?php echo $nefro2; ?>/><label>N&atilde;o</label>
		<input name="nefro" type="radio" value="NA" onchange="savCampo('8')" <?php echo $nefro3; ?>/><label>N&atilde;o Avaliado</label>
	</span>
</fieldset>
<fieldset style="width:46%">
	<legend>Tuberculose</legend>
	<span>
		<input name="tuberc" type="radio" value="S" onchange="savCampo('8')" <?php echo $tuberc1; ?>/><label>Sim</label>
		<input name="tuberc" type="radio" value="N" onchange="savCampo('8')" <?php echo $tuberc2; ?>/><label>N&atilde;o</label>
		<input name="tuberc" type="radio" value="NA" onchange="savCampo('8')" <?php echo $tuberc3; ?>/><label>N&atilde;o Avaliado</label>
	</span>
</fieldset>

<fieldset style="width:46%">
	<legend>Asma</legend>
	<span>
		<input name="asma" type="radio" value="S" onchange="savCampo('8')" <?php echo $asma1; ?>/><label>Sim</label>
		<input name="asma" type="radio" value="N" onchange="savCampo('8')" <?php echo $asma2; ?>/><label>N&atilde;o</label>
		<input name="asma" type="radio" value="NA" onchange="savCampo('8')" <?php echo $asma3; ?>/><label>N&atilde;o Avaliado</label>
	</span>
</fieldset>
<fieldset style="width:46%">
	<legend>Eczema</legend>
	<span>
		<input name="eczema" type="radio" value="S" onchange="savCampo('8')" <?php echo $eczema1; ?>/><label>Sim</label>
		<input name="eczema" type="radio" value="N" onchange="savCampo('8')" <?php echo $eczema2; ?>/><label>N&atilde;o</label>
		<input name="eczema" type="radio" value="NA" onchange="savCampo('8')" <?php echo $eczema3; ?>/><label>N&atilde;o Avaliado</label>
	</span>
</fieldset>

<fieldset class="full">
	<legend id="lblalerg" <?php if (isset($_POST['$lblalerg'])) echo $lblalerg; ?>>Alergia Alimentar</legend>
	<span>
		<input name="alerg" type="radio" value="S" onclick="habilitaAlergia(1)" onfocus="mudaLb(lblalerg)" <?php echo $alerg1; ?> onchange="savCampo('8')"/><label>Sim</label>
		<input name="alerg" type="radio" value="N" onclick="habilitaAlergia(0)" onfocus="mudaLb(lblalerg)" <?php echo $alerg2;?> onchange="savCampo('8')"/><label>N&atilde;o</label>
		<input name="alerg" type="radio" value="NA" onclick="habilitaAlergia(0)" onfocus="mudaLb(lblalerg)" <?php echo $alerg3; ?> onchange="savCampo('8')"/><label>N&atilde;o Avaliado</label>
	</span>
	<textarea class="txta1" name="talerg" onkeyup="savCampo('8')" onfocus="mudaLb(lblalerg)" <?php echo $dalerg; ?>><?php echo $talerg; ?></textarea>
</fieldset>

<fieldset style="width:46%">
	<legend>Rinite Al&eacute;rgica</legend>
	<span>
		<input name="rinite" type="radio" value="S" onchange="savCampo('8')" <?php echo $rinite1; ?>/><label>Sim</label>
		<input name="rinite" type="radio" value="N" onchange="savCampo('8')" <?php echo $rinite2; ?>/><label>N&atilde;o</label>
		<input name="rinite" type="radio" value="NA" onchange="savCampo('8')" <?php echo $rinite3; ?>/><label>N&atilde;o Avaliado</label>
	</span>
</fieldset>
<fieldset style="width:46%">
	<legend>Cirurgias e Acidentes</legend>
	<span>
		<input name="cirurg" type="radio" value="S" onchange="savCampo('8')" <?php echo $cirurg1; ?>/><label>Sim</label>
		<input name="cirurg" type="radio" value="N" onchange="savCampo('8')" <?php echo $cirurg2; ?>/><label>N&atilde;o</label>
		<input name="cirurg" type="radio" value="NA" onchange="savCampo('8')" <?php echo $cirurg3; ?>/><label>N&atilde;o Avaliado</label>
	</span>
</fieldset>

<fieldset style="width:46%">
	<legend>Hist&oacute;rico de Transfus&otilde;es</legend>
	<span>
		<input name="transf" type="radio" value="S" onchange="savCampo('8')" <?php echo $transf1; ?>/><label>Sim</label>
		<input name="transf" type="radio" value="N" onchange="savCampo('8')" <?php echo $transf2; ?>/><label>N&atilde;o</label>
		<input name="transf" type="radio" value="NA" onchange="savCampo('8')" <?php echo $transf3; ?>/><label>N&atilde;o Avaliado</label>
	</span>
</fieldset>
<fieldset style="width:46%">
	<legend>Hospitaliza&ccedil;&otilde;es</legend>
	<span>
		<input name="hospit" type="radio" value="S" onchange="savCampo('8')" <?php echo $hospit1; ?>/><label>Sim</label>
		<input name="hospit" type="radio" value="N" onchange="savCampo('8')" <?php echo $hospit2; ?>/><label>N&atilde;o</label>
		<input name="hospit" type="radio" value="NA" onchange="savCampo('8')" <?php echo $hospit3; ?>/><label>N&atilde;o Avaliado</label>
	</span>
</fieldset>

<fieldset class="full">
	<legend id="lbltreal">Tratamentos Realizados</legend>
	<textarea class="txta1" name="trata" onkeyup="savCampo('8')" onfocus="mudaLb(lbltreal)"><?php echo $trata; ?></textarea>
</fieldset>

<fieldset class="full">
	<legend>Observa&ccedil;&otilde;es</legend>
	<textarea class="txta1" name="obsdoenant" onkeyup="savCampo('5')"><?php echo $obsdoenant; ?></textarea>
</fieldset>