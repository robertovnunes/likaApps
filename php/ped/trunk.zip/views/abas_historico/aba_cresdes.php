<br />
<span class="style7">Pessoal > Crescimento e Desenvolvimento</span>
<br />
<fieldset class="full">
	<legend>Rela&ccedil;&atilde;o com os Irm&atilde;os</legend>
	<textarea class="txta1" name="relirm" onkeyup="savCampo('5')"><?php echo $relirm; ?></textarea>
</fieldset>

<fieldset style="width:46%">
	<legend>Idade que Foi &agrave; Escola</legend>
	<select name="idadesc" onchange="savCampo('5')">
		<option value='610' <?php echo $idadesc1; ?>>Entre 6 e 10 anos</option>
		<option value='-6' <?php echo $idadesc2; ?>>Antes dos 6 anos</option>
		<option value='+10' <?php echo $idadesc3; ?>>Depois dos 10 anos</option>
		<option value='NF' <?php echo $idadesc4; ?>>N&atilde;o foi</option>
		<option value='NA' <?php echo $idadesc5; ?>>N&atilde;o Avaliado</option>
	</select>
</fieldset>

<fieldset class="full">
	<legend>Aprendizado</legend>
	<textarea class="txta1" name="aprend" onkeyup="savCampo('5')"><?php echo $aprend;?></textarea>
</fieldset>

<fieldset class="full">
	<legend>Repet&ecirc;ncia de Ano</legend>
	<textarea class="txta1" name="repetano" onkeyup="savCampo('5')"><?php echo $repetano; ?></textarea>
</fieldset>

<fieldset class="full">
	<legend>Relacionamento com Colegas e Professores</legend>
	<textarea class="txta1" name="relacol" onkeyup="savCampo('5')"><?php echo $relacol; ?></textarea>
</fieldset>

<fieldset class="full">
	<legend>Particularidades da Fala</legend>
	<textarea class="txta1" name="partfala" onkeyup="savCampo('5')"><?php echo $partfala; ?></textarea>
</fieldset>

<fieldset class="full">
	<legend>Erup&ccedil;&atilde;o e Mudan&ccedil;a Dent&aacute;ria</legend>
	<textarea class="txta1" name="muddent" onkeyup="savCampo('5')" ><?php echo $muddent; ?></textarea>
</fieldset>

<fieldset class="full">
	<legend>Observa&ccedil;&otilde;es</legend>
	<textarea class="txta1" name="obscrescdes" onkeyup="savCampo('5')"><?php echo $obscrescdes;?></textarea>
</fieldset>