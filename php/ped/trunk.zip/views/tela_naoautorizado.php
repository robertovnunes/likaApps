<?php
	include ("validar_session.php");
?>

<span class="nautorizado">Voc&ecirc; n&atilde;o est&aacute; autorizado a consultar este prontu&aacute;rio.</span>
<br /><br />
<a class="nautorizado" href="acesso_aluno.php">Voltar</a>
