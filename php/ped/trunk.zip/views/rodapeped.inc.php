	<div id="rodape" <?php if($pagina != "index.php") { echo 'style="z-index:-1"';} ?>>
		<div id="rodapeimg">
		<img src="images/rodape2.png" width="1290">
		</div>
		<div id="logoUFPE"> <img src="images/logo_r2_c2.jpg">
			<div id="copyr"> � Copyright iDEIAS 2009
			  </div>
	     	</div>
			<div id="webDesign">iR4 Consultoria Web</div>
			<div id="logoiDEIAS"> <img src="images/iDEIAs - reduzido.gif"></div>
			<div id="logoLIKA"> <img src="images/lika_marca_reduzido.gif" ></div>
			<div id="logoHC"> <img src="images/logoHC.jpg"> </div>
			<div id="recomenda">Site melhor visualizado no Mozilla Firefox 10+ ou Google Chrome, em resolu��o 1280 x 1024 pixels. </div>
	</div>
</div>  
</body>
</html>
