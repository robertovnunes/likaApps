<div id="dataHora" class="style4"><br /><strong>
	<script language="JavaScript" type="text/javascript">hora()</script>
	<span id="timer" ></span> -
	<script language="JavaScript" type="text/javascript">renderDate()</script>
	<span id="data"></span></strong><br /><br />
</div>