<fieldset style="width:44%">
	<legend>O Beb&ecirc; reconhece a voz da m&atilde;e</legend>
	<select name="brvm" <?php echo $ass; ?> onchange="savCampo('5')">
		<option value="2" <?php echo $brvm1; ?>>At&eacute; 2 meses</option>
		<option value="2+" <?php echo $brvm2; ?>>Depois de 2 meses</option>
		<option value="NA" <?php echo $brvm3; ?>>N&atilde;o Avaliado</option>
	</select>
</fieldset>
<fieldset style="width:48%">
	<legend>Olha o rosto das pessoas  pr&oacute;ximas</legend>
	<select name="orpp" <?php echo $ass; ?> onchange="savCampo('5')">
		<option value="2" <?php echo $orpp1; ?>>At&eacute; 2 meses</option>
		<option value="2+" <?php echo $orpp2; ?>>Depois de 2 meses</option>
		<option value="NA" <?php echo $orpp3; ?>>N&atilde;o Avaliado</option>
	</select>
</fieldset>
<fieldset style="width:44%">
	<legend>Presta aten&ccedil;&atilde;o quando ouve sons</legend>
	<select name="paqos" <?php echo $ass; ?> onchange="savCampo('5')">
		<option value="2" <?php echo $paqos1; ?>>At&eacute; 2 meses</option>
		<option value="2+" <?php echo $paqos2; ?>>Depois de 2 meses</option>
		<option value="NA" <?php echo $paqos3; ?>>N&atilde;o Avaliado</option>
	</select>
</fieldset>
<fieldset style="width:48%">
	<legend>Responde ao sorriso com um sorriso</legend>
	<select name="rscs" <?php echo $ass; ?> onchange="savCampo('5')">
		<option value="2" <?php echo $rscs1; ?>>At&eacute; 2 meses</option>
		<option value="2+" <?php echo $rscs2; ?>>Depois de 2 meses</option>
		<option value="NA" <?php echo $rscs3; ?>>N&atilde;o Avaliado</option>
	</select>
</fieldset>
<fieldset style="width:44%">
	<legend>Posto de bru&ccedil;os, levanta  cabe&ccedil;a e ombros</legend>
	<select name="pblco" <?php echo $ass; ?> onchange="savCampo('5')">
		<option value="24" <?php echo $pblco1; ?>>Entre 2 e 4 meses</option>
		<option value="2-" <?php echo $pblco2; ?>>Antes de 2 meses</option>
		<option value="4+" <?php echo $pblco3; ?>>Depois de 4 meses</option>
		<option value="NA" <?php echo $pblco4; ?>>N&atilde;o Avaliado</option>
	</select>
</fieldset>
<fieldset style="width:48%">
	<legend>Segue com os olhos pessoas e objetos</legend>
	<select name="scopo" <?php echo $ass; ?> onchange="savCampo('5')">
		<option value="24" <?php echo $scopo1; ?>>Entre 2 e 4 meses</option>
		<option value="2-" <?php echo $scopo2; ?>>Antes de 2 meses</option>
		<option value="4+" <?php echo $scopo3; ?>>Depois de 4 meses</option>
		<option value="NA" <?php echo $scopo4; ?>>N&atilde;o Avaliado</option>
	</select>
</fieldset>
<fieldset style="width:44%">
	<legend>Brinca com a voz e tenta &quot;conversar&quot;</legend>
	<select name="bcvtc" <?php echo $ass; ?> onchange="savCampo('5')">
		<option value="24" <?php echo $bcvtc1; ?>>Entre 2 e 4 meses</option>
		<option value="2-" <?php echo $bcvtc2; ?>>Antes de 2 meses</option>
		<option value="4+" <?php echo $bcvtc3; ?>>Depois de 4 meses</option>
		<option value="NA" <?php echo $bcvtc4; ?>>N&atilde;o Avaliado</option>
	</select>
</fieldset>		
<fieldset style="width:48%">
	<legend>Brinca com as m&atilde;os  e as leva &agrave; boca</legend>
	<select name="bcmlb" <?php echo $ass; ?> onchange="savCampo('5')">
		<option value="24" <?php echo $bcmlb1; ?>>Entre 2 e 4 meses</option>
		<option value="2-" <?php echo $bcmlb2; ?>>Antes de 2 meses</option>
		<option value="4+" <?php echo $bcmlb3; ?>>Depois de 4 meses</option>
		<option value="NA" <?php echo $bcmlb4; ?>>N&atilde;o Avaliado</option>
	</select>
</fieldset>
<fieldset style="width:44%">
	<legend>O beb&ecirc; est&aacute; mais firme e senta com apoio</legend>
	<select name="bmfsa" <?php echo $ass; ?> onchange="savCampo('5')">
		<option value="46" <?php echo $bmfsa1; ?>>Entre 4 e 6 meses</option>
		<option value="4-" <?php echo $bmfsa2; ?>>Antes de 4 meses</option>
		<option value="6+" <?php echo $bmfsa3; ?>>Depois de 6 meses</option>
		<option value="NA" <?php echo $bmfsa4; ?>>N&atilde;o Avaliado</option>
	</select>
</fieldset>
<fieldset style="width:48%">
	<legend>Vira-se e rola sozinho</legend>
	<select name="vrs" <?php echo $ass; ?> onchange="savCampo('5')">
		<option value="46" <?php echo $vrs1; ?>>Entre 4 e 6 meses</option>
		<option value="4-" <?php echo $vrs2; ?>>Antes de 4 meses</option>
		<option value="6+" <?php echo $vrs3; ?>>Depois de 6 meses</option>
		<option value="NA" <?php echo $vrs4; ?>>N&atilde;o Avaliado</option>
	</select>
</fieldset>
<fieldset style="width:44%">
	<legend>Agarra brinquedos, segurando firme</legend>
	<select name="absf" <?php echo $ass; ?> onchange="savCampo('5')">
		<option value="46" <?php echo $absf1; ?>>Entre 4 e 6 meses</option>
		<option value="4-" <?php echo $absf2; ?>>Antes de 4 meses</option>
		<option value="6+" <?php echo $absf3; ?>>Depois de 6 meses</option>
		<option value="NA" <?php echo $absf4; ?>>N&atilde;o Avaliado</option>
	</select>
</fieldset>
<fieldset style="width:48%">
	<legend>Quando escuta algum barulho, tenta localiz&aacute;-lo</legend>
	<select name="qeabtl" <?php echo $ass; ?> onchange="savCampo('5')">
		<option value="46" <?php echo $qeabtl1; ?>>Entre 4 e 6 meses</option>
		<option value="4-" <?php echo $qeabtl2; ?>>Antes de 4 meses</option>
		<option value="6+" <?php echo $qeabtl3; ?>>Depois de 6 meses</option>
		<option value="NA" <?php echo $qeabtl4; ?>>N&atilde;o Avaliado</option>
	</select>
</fieldset>
<fieldset style="width:44%">
	<legend>O beb&ecirc; fica sentado sem apoio</legend>
	<select name="bfssa" <?php echo $ass; ?> onchange="savCampo('5')">
		<option value="69" <?php echo $bfssa1; ?>>Entre 6 e 9 meses</option>
		<option value="6-" <?php echo $bfssa2; ?>>Antes de 6 meses</option>
		<option value="9+" <?php echo $bfssa3; ?>>Depois de 9 meses</option>
		<option value="NA" <?php echo $bfssa4; ?>>N&atilde;o Avaliado</option>
	</select>
</fieldset>
<fieldset style="width:48%">
	<legend>Come&ccedil;a a se arrastar ou engatinhar</legend>
	<select name="cae" <?php echo $ass; ?> onchange="savCampo('5')">
		<option value="69" <?php echo $cae1; ?>>Entre 6 e 9 meses</option>
		<option value="6-" <?php echo $cae2; ?>>Antes de 6 meses</option>
		<option value="9+" <?php echo $cae3; ?>>Depois de 9 meses</option>
		<option value="NA" <?php echo $cae4; ?>>N&atilde;o Avaliado</option>
	</select>
</fieldset>
<fieldset style="width:44%">
	<legend>Passa objetos de uma m&atilde;o para a outra</legend>
	<select name="pomo" <?php echo $ass; ?> onchange="savCampo('5')">
		<option value="69" <?php echo $pomo1; ?>>Entre 6 e 9 meses</option>
		<option value="6-" <?php echo $pomo2; ?>>Antes de 6 meses</option>
		<option value="9+" <?php echo $pomo3; ?>>Depois de 9 meses</option>
		<option value="NA" <?php echo $pomo4; ?>>N&atilde;o Avaliado</option>
	</select>
</fieldset>
<fieldset style="width:48%">
	<legend>Estranha pessoas desconhecidas</legend>
	<select name="epd" <?php echo $ass; ?> onchange="savCampo('5')">
		<option value="69" <?php echo $epd1; ?>>Entre 6 e 9 meses</option>
		<option value="6-" <?php echo $epd2; ?>>Antes de 6 meses</option>
		<option value="9+" <?php echo $epd3; ?>>Depois de 9 meses</option>
		<option value="NA" <?php echo $epd4; ?>>N&atilde;o Avaliado</option>
	</select>
</fieldset>
<fieldset style="width:44%">
	<legend>Repete sons como &quot;pa-pa&quot;, &quot;ma-ma&quot;</legend>
	<select name="rspm" <?php echo $ass; ?> onchange="savCampo('5')">
		<option value="69" <?php echo $rspm1; ?>>Entre 6 e 9 meses</option>
		<option value="6-" <?php echo $rspm2; ?>>Antes de 6 meses</option>
		<option value="9+" <?php echo $rspm3; ?>>Depois de 9 meses</option>
		<option value="NA" <?php echo $rspm4; ?>>N&atilde;o Avaliado</option>
	</select>
</fieldset>
<fieldset style="width:48%">
	<legend>O beb&ecirc; pode ficar em p&eacute; com apoio</legend>
	<select name="bpfpca" <?php echo $ass; ?> onchange="savCampo('5')">
		<option value="9C" <?php echo $bpfpca1; ?>>Entre 9 e 12 meses</option>
		<option value="9-" <?php echo $bpfpca2; ?>>Antes de 9 meses</option>
		<option value="C+" <?php echo $bpfpca3; ?>>Depois de 12 meses</option>
		<option value="NA" <?php echo $bpfpca4; ?>>N&atilde;o Avaliado</option>
	</select>
</fieldset>
<fieldset style="width:44%">
	<legend>Bate palmas, aponta com o dedo, acena</legend>
	<select name="bpacda" <?php echo $ass; ?> onchange="savCampo('5')">
		<option value="9C" <?php echo $bpacda1; ?>>Entre 9 e 12 meses</option>
		<option value="9-" <?php echo $bpacda2; ?>>Antes de 9 meses</option>
		<option value="C+" <?php echo $bpacda3; ?>>Depois de 12 meses</option>
		<option value="NA" <?php echo $bpacda4; ?>>N&atilde;o Avaliado</option>
	</select>
</fieldset>
<fieldset style="width:48%">
	<legend>Pode falar uma ou duas palavras</legend>
	<select name="pfudp" <?php echo $ass; ?> onchange="savCampo('5')">
		<option value="9C" <?php echo $pfudp1; ?>>Entre 9 e 12 meses</option>
		<option value="9-" <?php echo $pfudp2; ?>>Antes de 9 meses</option>
		<option value="C+" <?php echo $pfudp3; ?>>Depois de 12 meses</option>
		<option value="NA" <?php echo $pfudp4; ?>>N&atilde;o Avaliado</option>
	</select>
</fieldset>
<fieldset style="width:44%">
	<legend>A crian�a anda sozinha</legend>
	<select name="cas" <?php echo $ass; ?> onchange="savCampo('5')">
		<option value="CI" <?php echo $cas1; ?>>Entre 1 ano e 1 ano e 6 meses</option>
		<option value="C-" <?php echo $cas2; ?>>Antes de 1 ano</option>
		<option value="I+" <?php echo $cas3; ?>>Depois de 1 ano e 6 meses</option>
		<option value="NA" <?php echo $cas4; ?>>N&atilde;o Avaliado</option>
	</select>
</fieldset>
<fieldset style="width:48%">
	<legend>compreende bem o que lhe dizem</legend>
	<select name="cbld" <?php echo $ass; ?> onchange="savCampo('5')">
		<option value="CI" <?php echo $cbld1; ?>>Entre 1 ano e 1 ano e 6 meses</option>
		<option value="C-" <?php echo $cbld2; ?>>Antes de 1 ano</option>
		<option value="I+" <?php echo $cbld3; ?>>Depois de 1 ano e 6 meses</option>
		<option value="NA" <?php echo $cbld4; ?>>N&atilde;o Avaliado</option>
	</select>
</fieldset>
<fieldset style="width:44%">
	<legend>Quer comer sozinha</legend>
	<select name="qcs" <?php echo $ass; ?> onchange="savCampo('5')">
		<option value="CI" <?php echo $qcs1; ?>>Entre 1 ano e 1 ano e 6 meses</option>
		<option value="C-" <?php echo $qcs2; ?>>Antes de 1 ano</option>
		<option value="I+" <?php echo $qcs3; ?>>Depois de 1 ano e 6 meses</option>
		<option value="NA" <?php echo $qcs4; ?>>N&atilde;o Avaliado</option>
	</select>
</fieldset>
<fieldset style="width:48%">
	<legend>Gosta de escutar  hist&oacute;rias, m&uacute;sicas e de dan&ccedil;ar</legend>
	<select name="gehmd" <?php echo $ass; ?> onchange="savCampo('5')">
		<option value="CI" <?php echo $gehmd1; ?>>Entre 1 ano e 1 ano e 6 meses</option>
		<option value="C-" <?php echo $gehmd2; ?>>Antes de 1 ano</option>
		<option value="I+" <?php echo $gehmd3; ?>>Depois de 1 ano e 6 meses</option>
		<option value="NA" <?php echo $gehmd4; ?>>N&atilde;o Avaliado</option>
	</select>
</fieldset>
<fieldset style="width:44%">
	<legend>Come&ccedil;a a fazer birra quando contrariada</legend>
	<select name="cfbqc" <?php echo $ass; ?> onchange="savCampo('5')">
		<option value="CI" <?php echo $cfbqc1; ?>>Entre 1 ano e 1 ano e 6 meses</option>
		<option value="C-" <?php echo $cfbqc2; ?>>Antes de 1 ano</option>
		<option value="I+" <?php echo $cfbqc3; ?>>Depois de 1 ano e 6 meses</option>
		<option value="NA" <?php echo $cfbqc4; ?>>N&atilde;o Avaliado</option>
	</select>
</fieldset>
<fieldset style="width:48%">
	<legend>Forma frases simples como &quot;leite n&atilde;o&quot;</legend>
	<select name="ffs" <?php echo $ass; ?> onchange="savCampo('5')">
		<option value="I2" <?php echo $ffs1; ?>>Entre 1 ano e 6 meses e 2 anos</option>
		<option value="I-" <?php echo $ffs2; ?>>Antes de 1 ano e 6 meses</option>
		<option value="2+" <?php echo $ffs3; ?>>Depois de 2 anos</option>
		<option value="NA" <?php echo $ffs4; ?>>N&atilde;o Avaliado</option>
	</select>
</fieldset>
<fieldset style="width:44%">
		<legend>Demonstra ter vontade pr&oacute;pria</legend>
		  <select name="dtvp" <?php echo $ass; ?> onchange="savCampo('5')">
			<option value="I2" <?php echo $dtvp1; ?>>Entre 1 ano e 6 meses e 2 anos</option>
			<option value="I-" <?php echo $dtvp2; ?>>Antes de 1 ano e 6 meses</option>
			<option value="2+" <?php echo $dtvp3; ?>>Depois de 2 anos</option>
			<option value="NA" <?php echo $dtvp4; ?>>N&atilde;o Avaliado</option>
	  </select>
</fieldset>
<fieldset style="width:48%">
	<legend>Corre, sobe e desce escadas, com adulto perto </legend>
	<select name="csde" <?php echo $ass; ?> onchange="savCampo('5')">
		<option value="I2" <?php echo $csde1; ?>>Entre 1 ano e 6 meses e 2 anos</option>
		<option value="I-" <?php echo $csde2; ?>>Antes de 1 ano e 6 meses</option>
		<option value="2+" <?php echo $csde3; ?>>Depois de 2 anos</option>
		<option value="NA" <?php echo $csde4; ?>>N&atilde;o Avaliado</option>
	</select>
</fieldset>
<fieldset style="width:44%">
	<legend>Pode ajudar a se vestir</legend>
	<select name="pasv" <?php echo $ass; ?> onchange="savCampo('5')">
		<option value="I2" <?php echo $pasv1; ?>>Entre 1 ano e 6 meses e 2 anos</option>
		<option value="I-" <?php echo $pasv2; ?>>Antes de 1 ano e 6 meses</option>
		<option value="2+" <?php echo $pasv3; ?>>Depois de 2 anos</option>
		<option value="NA" <?php echo $pasv4 ?>>N&atilde;o Avaliado</option>
	</select>
</fieldset>
<fieldset style="width:48%">
	<legend>Aprende a controlar o xixi e o coc&ocirc;</legend>
	<select name="acxc" <?php echo $ass; ?> onchange="savCampo('5')">
		<option value="I2" <?php echo $acxc1; ?>>Entre 1 ano e 6 meses e 2 anos</option>
		<option value="I-" <?php echo $acxc2; ?>>Antes de 1 ano e 6 meses</option>
		<option value="2+" <?php echo $acxc3; ?>>Depois de 2 anos</option>
		<option value="NA" <?php echo $acxc4; ?>>N&atilde;o Avaliado</option>
	</select>
</fieldset>
<fieldset style="width:44%">
	<legend>Sobe escadas, com  apoio do corrim&atilde;o</legend>
	<select name="secac" <?php echo $ass; ?> onchange="savCampo('5')">
		<option value="23" <?php echo $secac1; ?>>Entre 2 e 3 anos</option>
		<option value="2-" <?php echo $secac2; ?>>Antes de 2 anos</option>
		<option value="3+" <?php echo $secac3; ?>>Depois de 3 anos</option>
		<option value="NA" <?php echo $secac4; ?>>N&atilde;o Avaliado</option>
	</select>
</fieldset>
<fieldset style="width:48%">
	<legend>Come&ccedil;a a perguntar o nome de tudo</legend>
	<select name="cpnt" <?php echo $ass; ?> onchange="savCampo('5')">
		<option value="23" <?php echo $cpnt1; ?>>Entre 2 e 3 anos</option>
		<option value="2-" <?php echo $cpnt2; ?>>Antes de 2 anos</option>
		<option value="3+" <?php echo $cpnt3; ?>>Depois de 3 anos</option>
		<option value="NA" <?php echo $cpnt4; ?>>N&atilde;o Avaliado</option>
	</select>
</fieldset>
<fieldset style="width:44%">
	<legend>Gosta de brincar com outras crian&ccedil;as</legend>
	<select name="gboc" <?php echo $ass; ?> onchange="savCampo('5')">
		<option value="23" <?php echo $gboc1; ?>>Entre 2 e 3 anos</option>
		<option value="2-" <?php echo $gboc2; ?>>Antes de 2 anos</option>
		<option value="3+" <?php echo $gboc3; ?>>Depois de 3 anos</option>
		<option value="NA" <?php echo $gboc4; ?>>N&atilde;o Avaliado</option>
	</select>
</fieldset>
<fieldset style="width:48%">
	<legend>Veste-se sozinha</legend>
	<select name="vests" <?php echo $ass; ?> onchange="savCampo('5')">
		<option value="36" <?php echo $vests1; ?>>Entre 3 e 6 anos</option>
		<option value="3-" <?php echo $vests2; ?>>Antes de 3 anos</option>
		<option value="6+" <?php echo $vests3; ?>>Depois de 6 anos</option>
		<option value="NA" <?php echo $vests4; ?>>N&atilde;o Avaliado</option>
	</select>
</fieldset>
<fieldset style="width:44%">
	<legend>Fala de forma clara e compreens&iacute;vel</legend>
	<select name="ffcc" <?php echo $ass; ?> onchange="savCampo('5')">
		<option value="36" <?php echo $ffcc1; ?>>Entre 3 e 6 anos</option>
		<option value="3-" <?php echo $ffcc2; ?>>Antes de 3 anos</option>
		<option value="6+" <?php echo $ffcc3; ?>>Depois de 6 anos</option>
		<option value="NA" <?php echo $ffcc4; ?>>N&atilde;o Avaliado</option>
	</select>
</fieldset>
<fieldset style="width:48%">
	<legend>Pergunta muito &quot;por qu&ecirc;?&quot;</legend>
	<select name="pmpq" <?php echo $ass; ?> onchange="savCampo('5')">
		<option value="36" <?php echo $pmpq1; ?>>Entre 3 e 6 anos</option>
		<option value="3-" <?php echo $pmpq2; ?>>Antes de 3 anos</option>
		<option value="6+" <?php echo $pmpq3; ?>>Depois de 6 anos</option>
		<option value="NA" <?php echo $pmpq4; ?>>N&atilde;o Avaliado</option>
	</select>
</fieldset>
<fieldset class="full">
	<legend>Tem interesse por amigos e atividades independentes da fam&iacute;lia </legend>
	<select name="iaaif" <?php echo $ass; ?> onchange="savCampo('5')">
		<option value="6A" <?php echo $iaaif1; ?>>Entre 6 e 10 anos</option>
		<option value="6-" <?php echo $iaaif2; ?>>Antes de 6 anos</option>
		<option value="A+" <?php echo $iaaif3; ?>>Depois de 10 anos</option>
		<option value="NA" <?php echo $iaaif4; ?>>N&atilde;o Avaliado</option>
	</select>
</fieldset>
<fieldset class="full">
	<legend>Observa&ccedil;&otilde;es</legend>
	<textarea name="obsdes" class="txta1" onkeyup="savCampo('5')" <?php echo $ass; ?>><?php echo $obsdes; ?></textarea>
</fieldset>