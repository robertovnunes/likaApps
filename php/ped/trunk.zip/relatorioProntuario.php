<?php
include_once("controllers/ControllerGeral.php");
include_once("classes/basicas/Informante.php");
include_once("classes/basicas/Paciente.php");
include_once("controllers/ControllerProntuarioPaciente.php");
include_once("controllers/ControllerListaAtendimentos.php");
require_once('fpdf/fpdf.php');



$paciente = $fachada->obterPacienteAt($atend);

$valPac = array('','','','');

$valPac[0] = $fachada->printCampo($paciente->getNome(), $valPac[0]);
$valPac[1] = $fachada->printCampo($fachada->printData($paciente->getDTNasc()), $valPac[1]);
$valPac[2] = $fachada->printCampo($paciente->getSexo(), $valPac[2]);
$valPac[3] = $fachada->printCampo($paciente->getBairro(),$valPac[3]);

//Fun��o que retorna as iniciais do nome do paciente
$aux = explode(' ',$valPac[0]);

$i = 0;
while($aux[$i] != NULL ){
	
	$iniciais = $iniciais . substr($aux[$i],0,1);
	$i = $i + 1;
}

foreach ($listaatend as $t){                  
     $dataAtend = $t['dthr'];
     $dataAtendAlt = $t['dthralt'];
}

/*Configura��o do PDF*/

$pdf=new FPDF('P','mm','A4');
$pdf->AddPage();
$pdf->SetDrawColor(205,205,205);
$pdf->SetLineWidth(0.3);

/*---------------------Atendimento do Paciente------------------------*/
$pdf->SetFont('Arial','B',16);
$pdf->Cell(40,10,"Atendimento do Paciente",0,1);

/*---------------------Dados do Atendimento------------------------*/
$pdf->SetFont('Arial','B',14);
$pdf->Cell(0,10,"Dados do Atendimento",'LTR',1);
$pdf->SetFont('Arial','',12);
$pdf->Cell(0,5,"Data de Cria��o: $dataAtend",'LR',1);
$pdf->Cell(0,5,"�ltima Altera��o: $dataAtendAlt",'LR',1);
$pdf->Cell(0,0,"",'LBR',1);
$pdf->Ln(5);


/*---------------------Dados do Paciente------------------------*/
$pdf->SetFont('Arial','B',14);
$pdf->Cell(0,10,"Dados do Paciente",'LTR',1);
$pdf->SetFont('Arial','',12);

$pdf->Cell(0,5,"Atendimento: $atend",'LR',1);
$pdf->Cell(0,5,"Nome: $iniciais",'LR',1);
$pdf->Cell(0,5,"$valPac[1]",'LR',1);
if($valPac[2] == 'F')
	$pdf->Cell(0,5,"Feminino",'LR',1);
else
	$pdf->Cell(0,5,"Masculino",'LR',1);
$pdf->Cell(0,5,"$valPac[3]",'LR',1);
$pdf->Cell(0,0,"",'LBR',1);
$pdf->Ln(5);

$pdf->Output("hist�rico$iniciais",'I');

?>
