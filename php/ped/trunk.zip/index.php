<?php
	include_once("controllers/ControllerGeral.php");
	include_once("views/inicio_view.php");
?>