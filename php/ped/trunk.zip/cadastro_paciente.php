<?php
include_once("controllers/ControllerGeral.php");
include_once("classes/basicas/Paciente.php");
include_once("controllers/ControllerCadastrarPaciente.php");
include_once("views/aluno_view.php");
include_once("views/cadastro_paciente_view.php");
include_once("views/rodapeped.inc.php");
?>
