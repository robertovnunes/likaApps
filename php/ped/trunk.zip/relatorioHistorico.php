<?php

include_once("controllers/ControllerGeral.php");
include_once("classes/basicas/Paciente.php");
include_once("controllers/ControllerHistoricoPaciente.php");
require_once('fpdf/fpdf.php');


$pront = $_GET['pr'];
$paciente = $fachada->obterPacientePr($pront);

$valPac = array('','','','');

$valPac[0] = $fachada->printCampo($paciente->getNome(), $valPac[0]);
$valPac[1] = $fachada->printCampo($fachada->printData($paciente->getDTNasc()), $valPac[1]);
$valPac[2] = $fachada->printCampo($paciente->getSexo(), $valPac[2]);
$valPac[3] = $fachada->printCampo($paciente->getBairro(),$valPac[3]);

//Fun��o que retorna as iniciais do nome do paciente
$aux = explode(' ',$valPac[0]);

$i = 0;
while($aux[$i] != NULL ){
	
	$iniciais = $iniciais . substr($aux[$i],0,1);
	$i = $i + 1;
}

/*Configura��o do PDF*/

$pdf=new FPDF('P','mm','A4');
$pdf->AddPage();
$pdf->SetDrawColor(205,205,205);
$pdf->SetLineWidth(0.3);

/*---------------------Hist�rico do Paciente------------------------*/
$pdf->SetFont('Arial','B',16);
$pdf->Cell(40,10,"Hist�rico do Paciente",0,1);

/*---------------------Dados do Paciente------------------------*/
$pdf->SetFont('Arial','B',14);
$pdf->Cell(0,10,"Dados do Paciente",'LTR',1);
$pdf->SetFont('Arial','',12);

$pdf->Cell(0,5,"Prontu�rio: $pront",'LR',1);
$pdf->Cell(0,5,"$iniciais",'LR',1);
$pdf->Cell(0,5,"$valPac[1]",'LR',1);
if($valPac[2] == 'F')
	$pdf->Cell(0,5,"Feminino",'LR',1);
else
	$pdf->Cell(0,5,"Masculino",'LR',1);
$pdf->Cell(0,5,"$valPac[3]",'LR',1);
$pdf->Cell(0,0,"",'LBR',1);
$pdf->Ln(5);

/*---------------------Pr�-Natal------------------------*/
$pdf->SetFont('Arial','B',14);
$pdf->Cell(0,5,"Pr�-Natal",'LTR',1);

$pdf->SetFont('Arial','',12);

	if($acpmed1){
		$pdf->Cell(0,5,"Acompanhamento M�dico: $lpnat->acpmed",'LR',1); 
	 	$pdf->Cell(0,5,"Local: $lpnat->lacpmed",'LR',1);
		
		if($lpnat->nacpmed && $lpnat->nacpmed != 'NA')
	 		$pdf->Cell(0,5,"N� de Consultas: $lpnat->nacpmed",'LR',1);	
	}
	elseif($acpmed2)
		$pdf->Cell(0,5,"Acompanhamento M�dico: N�o",'LR',1);
	if($lpnat->durgest && $lpnat->durgest != 'NA')
	 	$pdf->Cell(0,5,"Dura��o da Gesta��o: $lpnat->durgest",'LR',1);
	 if($lpnat->idSang != '0'){	
	 	foreach ($sang as $s){
	 		
	 		if($s['idSang'] == $lpnat->idSang)
	 			$sangmaeAUX = $s['tipo']; 	
		}
		
	if($sangmaeAUX)
	 	$pdf->Cell(0,5,"Grupo Sangu�neo da M�e: $sangmaeAUX",'LR',1);	
	 }
	 
	if($lpnat->z21 && $lpnat->z21 != 'NA')
	 	$pdf->Cell(0,5,"Z21: $lpnat->z21",'LR',1);	
	if($lpnat->a53 && $lpnat->a53 != 'NA')
	 	$pdf->Cell(0,5,"A53: $lpnat->a53",'LR',1);	
	if($lpnat->b18 && $lpnat->b18 != 'NA')
	 	$pdf->Cell(0,5,"B18: $lpnat->b18",'LR',1);	 
	if($lpnat->b58 && $lpnat->b58 != 'NA')
	 	$pdf->Cell(0,5,"B58: $lpnat->b58",'LR',1);	
	 if($lpnat->imunizmae && $lpnat->imunizmae != 'NA')
	 	$pdf->Cell(0,5,"Imuniza��es da M�e: $lpnat->imunizmae",'LR',1);	
	if($lpnat->exradion && $lpnat->exradion != 'NA')
	 	$pdf->Cell(0,5,"Exames Radia��o Ionizante: $lpnat->exradion",'LR',1);	
	if($lpnat->medic && $lpnat->medic != 'NA')
	 	$pdf->MultiCell(0,5,"Medica��es: $lpnat->medic",'LR',1);	
	if($lpnat->anorm && $lpnat->anorm != 'NA')
	 	$pdf->MultiCell(0,5,"Anormalidades: $lpnat->anorm",'LR',1);	
	if($lpnat->doencir && $lpnat->doencir != 'NA')
	 	$pdf->Cell(0,5,"Doen�as Cir�rgicas: $lpnat->doencir",'LR',1);	
	 if($lpnat->cirurgdc && $lpnat->cirurgdc != 'NA')
		$pdf->MultiCell(0,5,"Cirurgias: $lpnat->cirurgdc",'LR',1);	
	if($lpnat->pesograv && $lpnat->pesograv != 'NA')
	 	$pdf->Cell(0,5,"Peso na Gravidez: $lpnat->pesograv",'LR',1);	
	if($lpnat->anemia && $lpnat->anemia != 'NA')
	 	$pdf->Cell(0,5,"Anemia: $lpnat->anemia",'LR',1);	
	if($lpnat->alimgrav && $lpnat->alimgrav != 'NA')
	 	$pdf->Cell(0,5,"Alimenta��o da Gravidez: $lpnat->alimgrav",'LR',1);	
	if($lpnat->obs && $lpnat->obs != 'NA')
	 	$pdf->MultiCell(0,5,"Observa��es:  $lpnat->obs",'LR',1);
	 $pdf->Cell(0,0,"",'LBR');
	 $pdf->Ln(5);
	// $pdf->Ln(5);

/*---------------------Natal------------------------*/
$pdf->SetFont('Arial','B',14);
$pdf->Cell(0,5,"Natal",'LTR',1);

$pdf->SetFont('Arial','',12);

	if($lnat->tgrav != 'NA' && $lnat->tgrav)
		$pdf->Cell(0,5,"Tipo de Gravidez:  $lnat->tgrav",'LR',1);
	if($lnat->tparto != 'NA' && $lnat->tparto)
		$pdf->Cell(0,5,"Tipo de Parto:  $lnat->tparto",'LR',1);
	if($lnat->tapres != 'NA' && $lnat->tapres)
		$pdf->Cell(0,5,"Tipo de Apresenta��o:  $lnat->tapres",'LR',1);
	if($lnat->durparto  && $lnat->durparto != 'NA')
		$pdf->Cell(0,5,"Dura��o Trabalho de Parto:  $lnat->durparto",'LR',1);
	if($lnat->anest != 'NA' && $lnat->anest)
		$pdf->Cell(0,5,"Anestesia:  $lnat->anest",'LR',1);
	if($lnat->analg)
		$pdf->MultiCell(0,5,"Analgesia:  $lnat->analg",'LR',1);
	if($lnat->complp == 'S')
		$pdf->MultiCell(0,5,"Complica��es:  $lnat->tcomplp",'LR',1);
	elseif($lnat->compl == 'N')
		$pdf->MultiCell(0,5,"Complica��es:  N�o",'LR',1);
	if($lnat->obs)
		$pdf->MultiCell(0,5,"Observa��es:  $lnat->obs",'LR',1);
	$pdf->Cell(0,0,"",'LBR',1);
	$pdf->Ln(5);
	
/*---------------------Neo-Natal------------------------*/
$pdf->SetFont('Arial','B',14);
$pdf->Cell(0,5,"Neo-Natal",'LTR',1);

$pdf->SetFont('Arial','',12);

	if($lnnat->apgar1 != 'NA' && $lnnat->apgar1)
		$pdf->Cell(0,5,"Apgar de 1 Minuto:  $lnnat->apgar1",'LR',1);
	if($lnnat->apgar5 != 'NA' && $lnnat->apgar5)
		$pdf->Cell(0,5,"Apgar de 5 Minutos:  $lnnat->apgar5",'LR',1);
	if($lnnat->idadegest != 'NA' && $lnnat->idadegest)
		$pdf->Cell(0,5,"Idade Gestacional:  $lnnat->idadegest",'LR',1);
	if($lnnat->idSang != '0' && $lnnat->idSang){	
	 	foreach ($sang as $s){
	 		
	 		if($s['idSang'] == $lnnat->idSang)
	 			$sangrnAUX = $s['tipo']; 	
		}
		
	 	$pdf->Cell(0,5,"Grupo Sangu�neo do RN: $sangrnAUX",'LR',1);	
	 }
	if($lnnat->permnasal != 'NA' && $lnnat->permnasal)
		$pdf->Cell(0,5,"Permeabilidade Nasal:  $lnnat->permnasal",'LR',1);
	if($lnnat->sinorto != 'NA' && $lnnat->sinorto)
		$pdf->Cell(0,5,"Sinal de Ortolani:  $lnnat->sinorto",'LR',1);
	if($lnnat->pesonasc != 'NA' && $lnnat->pesonasc)
		$pdf->Cell(0,5,"Peso ao Nascer:  $lnnat->pesonasc",'LR',1);
	if($lnnat->comp != 'NA' && $lnnat->comp)
		$pdf->Cell(0,5,"Comprimento ao Nascer:  $lnnat->comp",'LR',1);
	if($lnnat->pesoalta != 'NA' && $lnnat->pesoalta)
		$pdf->Cell(0,5,"Peso na Alta:  $lnnat->pesoalta",'LR',1);
	if($lnnat->pesoat && $lnnat->pesoat)
		$pdf->Cell(0,5,"Peso Atual:  $lnnat->pesoat",'LR',1);
	if($lnnat->altat && $lnnat->altat)
		$pdf->Cell(0,5,"Altura Atual:  $lnnat->altat",'LR',1);
	if($lnnat->percef != 'NA'  && $lnnat->percef)
		$pdf->Cell(0,5,"Per�metro Cef�lico:  $lnnat->percef",'LR',1);
	if($lnnat->pertorac != 'NA' && $lnnat->pertorac)
		$pdf->Cell(0,5,"Per�metro Tor�cico:  $lnnat->pertorac",'LR',1);
	if($lnnat->testepe == 'S'){
		$pdf->Cell(0,5,"Teste do Pezinho: $lnnat->testepe ",'LR',1);
		if($lnnat->fenilcet && $lnnat->fenilcet != 'NA')
			$pdf->Cell(0,5,"Fenilceton�ria:  $lnnat->fenilcet",'LR',1);
		if($lnnat->hipotir && $lnnat->hipotir != 'NA')
			$pdf->Cell(0,5,"Hipotiroidismo:  $lnnat->hipotir",'LR',1);
		if($lnnat->anemfalc && $lnnat->anemfalc != 'NA')
			$pdf->Cell(0,5,"Anemia Falciforme: $lnnat->anemfalc",'LR',1);
	}
	elseif($lnnat->testepe == 'N')
		$pdf->Cell(0,5,"Teste do Pezinho: N�o ",'LR',1);
	
	if($lnnat->triagaud == 'S'){
			$pdf->Cell(0,5,"Triagem Auditiva:  $lnnat->triagaud",'LR',1);
			if($lnnat->peate != 'NA' && $lnnat->peate)
				$pdf->Cell(0,5,"PEATE:  $lnnat->peate",'LR',1);
			if($lnnat->eoa != 'NA' && $lnnat->eoa)
				$pdf->Cell(0,5,"EOA:  $lnnat->eoa",'LR',1);
	}
	elseif($lnnat->triagaud == 'N')
		$pdf->Cell(0,5,"Triagem Auditiva: N�o ",'LR',1);
		
	if($lnnat->icter != 'NA' && $lnnat->icter)
				$pdf->Cell(0,5,"Icter�cia:  $lnnat->icter",'LR',1);
	if($lnnat->reanim != 'NA' && $lnnat->reanim)
				$pdf->Cell(0,5,"Reanima��o: $lnnat->reanim",'LR',1);
	if($lnnat->rash != 'NA' && $lnnat->rash)
				$pdf->Cell(0,5,"Rash:  $lnnat->rash",'LR',1);
	if($lnnat->sang != 'NA' && $lnnat->sang)
				$pdf->Cell(0,5,"Sangramentos:  $lnnat->sang",'LR',1);
	if($lnnat->vomit != 'NA' && $lnnat->vomit)
				$pdf->Cell(0,5,"Vomitos:  $lnnat->vomit",'LR',1);
	if($lnnat->infec != 'NA' && $lnnat->infec)
				$pdf->Cell(0,5,"Infec��es:  $lnnat->infec",'LR',1);
	if($lnnat->anomcong != 'NA' && $lnnat->anomcong)
				$pdf->Cell(0,5,"Anomalias Cong�nitas:  $lnnat->anomcong",'LR',1);
	if($lnnat->paral != 'NA' && $lnnat->paral)
				$pdf->Cell(0,5,"Paralisias:  $lnnat->paral",'LR',1);
	if($lnnat->coriza != 'NA' && $lnnat->coriza)
				$pdf->Cell(0,5,"Coriza:  $lnnat->coriza",'LR',1);
	if($lnnat->convul != 'NA' && $lnnat->convul)
				$pdf->Cell(0,5,"Convul��es:  $lnnat->convul",'LR',1);			
	if($lnnat->obs)
				$pdf->MultiCell(0,5,"Observa��es:  $lnnat->obs",'LR',1);
	$pdf->Cell(0,0,"",'LBR',1);
	$pdf->Ln(5);
				
/*---------------------Alimenta��o------------------------*/

$pdf->SetFont('Arial','B',14);
$pdf->Cell(0,5,"Alimenta��o",'LTR',1);

$pdf->SetFont('Arial','',12);

	if($lalim->aleitmat != 'NA' && $lalim->aleitmat)
				$pdf->Cell(0,5,"Aleitamento Materno Exclusivo:  $lalim->aleitmat",'LR',1);
	if($lalim->alimcomp != 'NA' && $lalim->alimcomp)
				$pdf->Cell(0,5,"In�cio Alimenta��o Complementar:  $lalim->alimcomp",'LR',1);
	if($lalim->alimpast != 'NA' && $lalim->alimpast)
				$pdf->Cell(0,5,"In�cio da Alimenta��o Pastosa:  $lalim->alimpast",'LR',1);
	if($lalim->alimfam != 'NA' && $lalim->alimfam)
				$pdf->Cell(0,5,"In�cio da Alimenta��o Familiar:  $lalim->alimfam",'LR',1);
	if($lalim->dietaat != 'NA' && $lalim->dietaat)
				$pdf->Cell(0,5,"Dieta Atual:  $lalim->dietaat",'LR',1);
	if($lalim->refdia && $lalim->refdia !='NA')
				$pdf->Cell(0,5,"N�mero de Refei��es Di�rias:  $lalim->refdia",'LR',1);
	if($lalim->horaref != 'NA' && $lalim->horaref)
				$pdf->Cell(0,5,"Hor�rio das Refei��es:  $lalim->horaref",'LR',1);
	if($lalim->mamadeira  && $lalim->mamadeira != 'NA')
				$pdf->Cell(0,5,"Uso da Mamadeira:  $lalim->mamadeira",'LR',1);
	if($lalim->colher != 'NA'  && $lalim->colher)
				$pdf->Cell(0,5,"Uso de Colher:  $lalim->colher",'LR',1);
	if($lalim->copo != 'NA' && $lalim->copo)
				$pdf->Cell(0,5,"Uso de Copo:  $lalim->copo",'LR',1);
	if($lalim->chantafet != 'NA' && $lalim->chantafet)
				$pdf->Cell(0,5,"Uso de Chantagem Afetiva:  $lalim->chantafet",'LR',1);
	if($lalim->alimpastl != 'NA' && $lalim->alimpastl)
				$pdf->Cell(0,5,"Alimenta��o Pastosa Liquidificada:  $lalim->alimpastl",'LR',1);
	if($lalim->brincref != 'NA' && $lalim->brincref)
				$pdf->Cell(0,5,"Brincadeira na Hora das Refei��es:  $lalim->brincref",'LR',1);
	if($lalim->obs)
				$pdf->MultiCell(0,5,"Observa��es:  $lalim->obs",'LR',1);
	$pdf->Cell(0,0,"",'LBR',1);
	$pdf->Ln(5);
				

/*---------------------"Crescimento e Desenvolvimento------------------------*/

$pdf->SetFont('Arial','B',14);
$pdf->Cell(0,5,"Crescimento e Desenvolvimento",'LTR',1);

$pdf->SetFont('Arial','',12);

	if($lcd->relirm && $lcd->relirm != 'NA')
				$pdf->MultiCell(0,5,"Rela��o com os Irm�os:  $lcd->relirm",'LR',1);
	if($lcd->idadesc && $lcd->idadesc != 'NA')
				$pdf->Cell(0,5,"Idade que Foi � Escola:  $lcd->idadesc",'LR',1);
	if($lcd->aprend && $lcd->aprend != 'NA')
				$pdf->MultiCell(0,5,"Aprendizado:  $lcd->aprend",'LR',1);
	if($lcd->repetano && $lcd->repetano != 'NA')
				$pdf->MultiCell(0,5,"Repet�ncia de Ano:  $lcd->repetano",'LR',1);
	if($lcd->relacol && $lcd->relacol != 'NA')
				$pdf->MultiCell(0,5,"Relacionamento com Colegas e Professores:  $lcd->relacol",'LR',1);
	if($lcd->partfala && $lcd->partfala != 'NA')
				$pdf->MultiCell(0,5,"Particularidades da Fala:  $lcd->partfala",'LR',1);
	if($lcd->muddent && $lcd->muddent != 'NA')
				$pdf->MultiCell(0,5,"Erup��o e Mudan�a Dent�ria:  $lcd->muddent",'LR',1);
	if($lcd->obs)
				$pdf->MultiCell(0,5,"Observa��es:  $lcd->obs",'LR',1);
	$pdf->Cell(0,0,"",'LBR',1);
	$pdf->Ln(5);

/*---------------------H�bitos------------------------*/	

$pdf->SetFont('Arial','B',14);
$pdf->Cell(0,5,"H�bitos",'LTR',1);

$pdf->SetFont('Arial','',12);


if($lhab->chupeta != 'NA' && $lhab->chupeta)
	$pdf->Cell(0,5,"Chupeta:  $lhab->chupeta",'LR',1);
if($lhab->chupadedo != 'NA' && $lhab->chupadedo)
	$pdf->Cell(0,5,"Chupa Dedo:  $lhab->chupadedo",'LR',1);
if($lhab->roiunha != 'NA' && $lhab->roiunha)
	$pdf->Cell(0,5,"R�i Unhas:  $lhab->roiunha",'LR',1);
if($lhab->tique != 'NA' && $lhab->tique)
	$pdf->Cell(0,5,"Tiques:  $lhab->tique",'LR',1);
if($lhab->altalim != 'NA' && $lhab->altalim)
	$pdf->Cell(0,5,"Altera��es na Alimenta��o:  $lhab->altalim",'LR',1);
if($lhab->geofagia != 'NA' && $lhab->geofagia)
	$pdf->Cell(0,5,"Geofagia:  $lhab->geofagia",'LR',1);
if($lhab->enurese != 'NA' && $lhab->enurese)
	$pdf->Cell(0,5,"Enurese:  $lhab->enurese",'LR',1);
if($lhab->pertsono != 'NA' && $lhab->pertsono)
	$pdf->Cell(0,5,"Pertuba��es do Sono:  $lhab->pertsono",'LR',1);
if($lhab->dormepais != 'NA' && $lhab->dormepais)
	$pdf->Cell(0,5,"Dorme na Cama dos Pais:  $lhab->dormepais",'LR',1);
if($lhab->obs)
	$pdf->MultiCell(0,5,"Observa��es:  $lhab->obs",'LR',1);
	$pdf->Cell(0,0,"",'LBR',1);
	$pdf->Ln(5);


/*---------------------Imuniza��es------------------------*/

$pdf->SetFont('Arial','B',14);
$pdf->Cell(0,5,"Imuniza��es",'LTR',1);

$pdf->SetFont('Arial','',12);

if($vacpac){
	foreach($vacpac as $lvac){
	 
	$vacina = $lvac['vacina'];
	$dose = $lvac['dose'];
	$datavac = $lvac['dt'];
		
	$pdf->Cell(40,5,"Vacina: $vacina",'L',0);
	$pdf->Cell(40,5,"Dose: $dose",'',0,'L');
	$pdf->Cell(0,5,"Data: $datavac",'R',1,'L');
	
	}
}
if($limun->efeitcol )
	$pdf->MultiCell(0,5,"Efeitos Colaterais:  $limun->efeitcol",'LR',1);
if($limun->testmant && $limun->testmant != 'NA')
	$pdf->Cell(0,5,"Teste de Mantoux:  $limun->testmant",'LR',1);
if($limun->obs)
	$pdf->Cell(0,5,"Observa��es:  $limun->obs",'LR',1);
$pdf->Cell(0,0,"",'LBR',1);
$pdf->Ln(5);
	
/*---------------------Doen�as Anteriores------------------------*/

$pdf->SetFont('Arial','B',14);
$pdf->Cell(0,5,"Doen�as Anteriores",'LTR',1);

$pdf->SetFont('Arial','',12);

if($ldoenc->coquel != 'NA' && $ldoenc->coquel)
	$pdf->Cell(0,5,"Coqueluche:  $ldoenc->coquel",'LR',1);
if($ldoenc->saramp !='NA' && $ldoenc->saramp)
	$pdf->Cell(0,5,"Sarampo:  $ldoenc->saramp",'LR',1);
if($ldoenc->varic != 'NA' && $ldoenc->varic)
	$pdf->Cell(0,5,"Varicela:  $ldoenc->varic",'LR',1);
if($ldoenc->parot != 'NA' && $ldoenc->parot)
	$pdf->Cell(0,5,"Parotide:  $ldoenc->parot",'LR',1);
if($ldoenc->dift != 'NA' && $ldoenc->dift)
	$pdf->Cell(0,5,"Difteria:  $ldoenc->dift",'LR',1);
if($ldoenc->tetano != 'NA' && $ldoenc->tetano)
	$pdf->Cell(0,5,"T�tano:  $ldoenc->tetano",'LR',1);
if($ldoenc->diarr != 'NA' && $ldoenc->diarr)
	$pdf->Cell(0,5,"Diarr�ia:  $ldoenc->diarr",'LR',1);
if($ldoenc->pneum != 'NA' && $ldoenc->pneum)
	$pdf->Cell(0,5,"Pneumonia:  $ldoenc->pneum",'LR',1);
if($ldoenc->mening != 'NA' && $ldoenc->mening)
	$pdf->Cell(0,5,"Meningite:  $ldoenc->mening",'LR',1);
if($ldoenc->febrer != 'NA' && $ldoenc->febrer)
	$pdf->Cell(0,5,"Febre Reum�tica:  $ldoenc->febrer",'LR',1);
if($ldoenc->nefro != 'NA' && $ldoenc->nefro)
	$pdf->Cell(0,5,"Nefropatia:  $ldoenc->nefro",'LR',1);	
if($ldoenc->tuberc != 'NA' && $ldoenc->tuberc)
	$pdf->Cell(0,5,"Tuberculose:  $ldoenc->tuberc",'LR',1);
if($ldoenc->asma != 'NA' && $ldoenc->asma)
	$pdf->Cell(0,5,"Asma:  $ldoenc->asma",'LR',1);
if($ldoenc->eczema != 'NA' && $ldoenc->eczema)
	$pdf->Cell(0,5,"Eczema:  $ldoenc->eczema",'LR',1);
if($ldoenc->alerg == 'S'){
	$pdf->MultiCell(0,5,"Alergia Alimentar: $ldoenc->talerg",'LR',1);
}elseif($ldoenc->alerg == 'N'){
	$pdf->Cell(0,5,"Alergia Alimentar:  N�o",'LR',1);
}
if($ldoenc->rinite != 'NA' && $ldoenc->rinite)
	$pdf->Cell(0,5,"Rinite Al�rgica:  $ldoenc->rinite",'LR',1);
if($ldoenc->cirurg != 'NA' && $ldoenc->cirurg)
	$pdf->Cell(0,5,"Cirurgias e Acidentes:  $ldoenc->cirurg",'LR',1);
if($ldoenc->transf != 'NA' && $ldoenc->transf)
	$pdf->Cell(0,5,"Hist�rico de Transfus�es:  $ldoenc->transf",'LR',1);
if($ldoenc->hospit != 'NA' && $ldoenc->hospit)
	$pdf->Cell(0,5,"Hospitaliza��es $ldoenc->hospit",'LR',1);
if($ldoenc->trata)
	$pdf->MultiCell(0,5,"Tratamentos Realizados:  $ldoenc->trata",'LR',1);
if($ldoenc->obs)
	$pdf->MultiCell(0,5,"Observa��es:  $ldoenc->obs",'LR',1);
$pdf->Cell(0,0,"",'LBR',1);
$pdf->Ln(5);

/*---------------------Outras Informa��es------------------------*/

$pdf->SetFont('Arial','B',14);
$pdf->Cell(0,5,"Outras Informa��es",'LTR',1);

$pdf->SetFont('Arial','',12);

if($linfo->chagas != "NA" && $linfo->chagas)
	$pdf->Cell(0,5,"Epidemiologia Para Doen�a de Chagas:  $linfo->chagas",'LR',1);
if($linfo->esquist != "NA" && $linfo->esquist)
	$pdf->Cell(0,5,"Epidemiologia Para Esquistossomose:  $linfo->esquist",'LR',1);
if($linfo->agtox != "NA" && $linfo->agtox){
	$pdf->Cell(0,5,"Exposi��o � Agentes T�xicos:  $linfo->agtox",'LR',1);
	if($linfo->agtox == "S")
		$pdf->MultiCell(0,5,"	>> $linfo->tagtox",'LR',1);
}
if($linfo->alergmed != "NA" && $linfo->alergmed){
	$pdf->Cell(0,5,"Alergia � Medicamento:  $linfo->alergmed",'LR',1);
	if($linfo->alergmed == "S")
		$pdf->MultiCell(0,5,"	>> $linfo->talergmed",'LR',1);
}
if($linfo->ctuberc != "NA" && $linfo->ctuberc)
	$pdf->Cell(0,5,"Contato com Tuberculose:  $linfo->ctuberc",'LR',1);
if($linfo->obs)
	$pdf->MultiCell(0,5,"Observa��es:  $linfo->obs",'LR',1);
	$pdf->Cell(0,0,"",'LBR',1);
	$pdf->Ln(5);
	
/*---------------------Hist�rico Familiar------------------------*/

$pdf->SetFont('Arial','B',14);
$pdf->Cell(0,5,"Hist�rico Familiar",'LTR',1);

$pdf->SetFont('Arial','',12);

if($linfam->uniaopais && $linfam->uniaopais != 'NA')
	$pdf->Cell(0,5,"Tipo de Uni�o dos Pais:  $linfam->uniaopais",'LR',1);
if($linfam->idademae && $linfam->idademae != 'NA')
	$pdf->Cell(0,5,"Idade da M�e:  $linfam->idademae",'LR',1);
if($linfam->profmae && $linfam->profmae != 'NA'){
	foreach($listcbo as $l){
		
		if($l['cod'] == $linfam->profmae)
			$profmaeAUX = $l['descricao'];
	}
	$pdf->Cell(0,5,"Ocupa��o da M�e:  $profmaeAUX",'LR',1);
}
if($linfam->idadepai && $linfam->idadepai != 'NA')
	$pdf->Cell(0,5,"Idade do Pai:  $linfam->idadepai",'LR',1);
if($linfam->profpai && $linfam->profpai != 'NA'){
	foreach($listcbo as $l){
		
		if($l['cod'] == $linfam->profpai)
			$profpaiAUX = $l['descricao'];
	}
	$pdf->Cell(0,5,"Ocupa��o do Pai: $profpaiAUX",'LR',1);
}

if($linfam->pais && $linfam->pais != 'NA')
	$pdf->MultiCell(0,5,"Detalhes:  $linfam->pais",'LR',1);
if($linfam->avos && $linfam->avos != 'NA')
	$pdf->MultiCell(0,5,"Av�s:  $linfam->avos",'LR',1);
if($linfam->irmaos && $linfam->irmaos != 'NA')
	$pdf->MultiCell(0,5,"Irm�os:  $linfam->irmaos",'LR',1);
if($linfam->outros && $linfam->outros != 'NA')
	$pdf->MultiCell(0,5,"Outros:  $linfam->outros",'LR',1);
if($lindom->resid && $lindom->resid != 'NA')
	$pdf->Cell(0,5,"Tipo de Resid�ncia:  $lindom->resid",'LR',1);
if($lindom->comod && $lindom->comod != 'NA')
	$pdf->Cell(0,5,"N� de C�modos:  $lindom->comod",'LR',1);
if($lindom->ocup && $lindom->ocup != 'NA')
	$pdf->Cell(0,5,"N� de Ocupantes:  $lindom->ocup",'LR',1);
if($lindom->agua && $lindom->agua != 'NA')
	$pdf->Cell(0,5,"�gua:  $lindom->agua",'LR',1);
if($lindom->sanea && $lindom->sanea != 'NA')
	$pdf->Cell(0,5,"Saneamento:  $lindom->sanea",'LR',1);
if($lindom->luz && $lindom->luz != 'NA')
	$pdf->Cell(0,5,"Luz:  $lindom->luz",'LR',1);
if($lindom->animais && $lindom->animais != 'NA')
	$pdf->Cell(0,5,"Presen�a de Animais:  $lindom->animais",'LR',1);
if($lindom->obs)
	$pdf->Cell(0,5,"Observa��es:  $lindom->obs",'LR',1);
	$pdf->Cell(0,0,"",'LBR',1);
	$pdf->Ln(5);
	


$pdf->Output("hist�rico$iniciais",'I');
?>
