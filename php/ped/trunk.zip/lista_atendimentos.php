<?php
include_once("controllers/ControllerGeral.php");
include_once("classes/basicas/Paciente.php");
include_once("controllers/ControllerListaAtendimentos.php");
include_once("views/aluno_view.php");
include_once("views/lista_atendimentos_view.php");
include_once("views/rodapeped.inc.php");
?>