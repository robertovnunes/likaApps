<?php
	include_once("controllers/ControllerGeral.php");
	include_once("controllers/ControllerEditarPerfil.php");
    include_once("views/aluno_view.php");
	include_once("views/editar_perfil_view.php");
	include_once("views/rodapeped.inc.php");
?>