<?php
	include_once("controllers/ControllerFale.php");
	include_once("views/fale_conosco_view.php");
	include_once("views/rodapeped.inc.php"); 
?>