<?php
	include_once("controllers/ControllerGeral.php");
	include_once("controllers/ControllerEnviaSenha.php");
	include_once("views/esqueceu_senha_view.php");
	include_once("views/rodapeped.inc.php"); 
?>