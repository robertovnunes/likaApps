<?php
/**
 * German language file
 *
 * @license    GPL 2 (http://www.gnu.org/licenses/gpl.html)
 */

$lang['discussion']        = 'Diskussion';
$lang['back_to_article']   = 'Zurück zum Artikel';
$lang['userpage']          = 'Benutzer-Seite';

/* accessibility headlines */
$lang['user_tools']        = 'Benutzer-Werkzeuge';
$lang['site_tools']        = 'Webseiten-Werkzeuge';
$lang['page_tools']        = 'Seiten-Werkzeuge';
$lang['skip_to_content']   = 'springe zum Inhalt';

//Setup VIM: ex: et ts=2 :
