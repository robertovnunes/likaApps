<?php
/**
 * Chinese (Simplified) language file
 *
 * @license    GPL 2 (http://www.gnu.org/licenses/gpl.html)
 */

$lang['discussion']   = '讨论';

//Setup VIM: ex: et ts=2 :
