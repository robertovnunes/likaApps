<?php
/**
 * Hungarian language file
 *
 * @license    GPL 2 (http://www.gnu.org/licenses/gpl.html)
 */

$lang['discussion']   = 'Vitalap';

//Setup VIM: ex: et ts=2 :
