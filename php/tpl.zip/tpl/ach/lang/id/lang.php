<?php
/**
 * Indonesian language file
 *
 * @license    GPL 2 (http://www.gnu.org/licenses/gpl.html)
 */

$lang['discussion']   = 'diskusi';

//Setup VIM: ex: et ts=2 :
