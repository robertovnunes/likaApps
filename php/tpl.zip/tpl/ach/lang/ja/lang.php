<?php
/**
 * Japanese language file
 *
 * @license    GPL 2 (http://www.gnu.org/licenses/gpl.html)
 */

$lang['discussion']   = 'ノート';

//Setup VIM: ex: et ts=2 :
