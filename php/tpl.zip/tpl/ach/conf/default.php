<?php
/*
 * default configuration settings
 *
 */

$conf['tagline']          = 'This is the tagline - explaining what this site is about.';
$conf['discussionPage']   = 'discussion:@ID@';
$conf['userPage']         = 'user:@USER@:';
$conf['sidebarID']        = 'sidebar';
$conf['hideTools']        = 0;
