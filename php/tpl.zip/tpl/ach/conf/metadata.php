<?php
/*
 * configuration metadata
 *
 */

$meta['tagline']          = array('string');
$meta['discussionPage']   = array('string');
$meta['userPage']         = array('string');
$meta['sidebarID']        = array('string');
$meta['hideTools']        = array('onoff');
