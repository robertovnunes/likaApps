== Description ==

Theme Name: Tidy
Theme URI: http://wpshop.com/theme/JzKLHbZuRdA1
Author: WP Shop byGMO
Author URI: http://wpshop.com/
Description: Tidy theme is the multi-purpose WordPress theme with ultimate simplicity.
The theme is fully customizable, responsive and flexible with full of revolutionary functions. Contents can turned on and off as desired, and a wide variety of layout options to help you build a satisfactory website. 
The theme is fully compatible with our original slider, social media integration, Google advertising & stats and web font plugins for
color customization and enhanced flexibility.
Version: 1.1.1
Tags: 
 black
 blue
 brown
 gray
 green
 orange
 pink
 purple
 red
 silver
 tan
 white
 yellow
 one-column
 two-columns
 three-columns
 four-columns
 left-sidebar
 right-sidebar
 fluid-layout
 responsive-layout
 custom-background
 custom-colors
 custom-header
 custom-menu
 editor-style
 featured-images
 full-width-template
 post-formats
 sticky-post
 theme-options
 threaded-comments

License: GNU General Public License
License URI: http://www.gnu.org/licenses/gpl-2.0.html


== Copyright ==
Tidy WordPress theme, Copyright (C) 2014 WP Shop byGMO
Tidy is licensed under the GPL.

Tidy WordPress theme is based on Underscores (_s) starter theme http://underscores.me/ 

== License ==
Unless otherwise specified, all the theme files, scripts and images are licensed under GNU General Public License version 2.

The image in the screenshot is from public domain http://unsplash.com/

== Theme Notes ==
You can drop your queries in our contact form in the following link.
http://support.wpshop.com/?page_id=15

== Instructions ==
Recommended Plugins for this theme. Download and activate plugins prior to an initial setup.  Please Refer to the plugin readme files for plugin insturctions.  

・JetPack for WordPress - Contact Form
・Simple Map
・GMO Showtime
・GMO Font Agent
・GMO Share Connection
・GMO Ads Master

To set up this theme's page pfererences, layout, color, meritbox, and social settings, use Theme Options. 

Settings
・General Settings -Theme Options>General
General settings allow you to set up Header Logo, Favicon, Site Title, Tagline and other texts. 
・Color Settings - Theme Options>Color
29 points of color change can be done.    
・Layout - Theme Options>Layout
To set up page layout preferences.
・Theme Options>Merit Box
Up to 4 merit boxes can be set up with custom icons.  It allows you to upload your own images too.
・Theme Options>Social
Most common social media icons can be set up here.  You can also choose icon color and locations.  

・You can drop your queries in our contact form in the following link.
http://support.wpshop.com/?page_id=15


